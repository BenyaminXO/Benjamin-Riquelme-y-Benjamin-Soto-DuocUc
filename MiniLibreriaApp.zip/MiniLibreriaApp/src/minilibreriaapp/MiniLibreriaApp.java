/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package minilibreriaapp;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Benya
 */
public class MiniLibreriaApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Libro> libros = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        
        System.out.println("====MENU====");
        System.out.println("1.- Registtrar libro");
        System.out.println("2.- Mostrar libros");
        System.out.println("3.- Vender ejemplares");
        System.out.println("4.- Salir");
        
        while(!salir){
            boolean libroEncontrado = false;
            boolean error = false;
            int id;
            String titulo;
            double precio;
            int cantidad;
            
            System.out.println("Ingrese la opcion elegida");
            int opcion = sc.nextInt();
            
            switch(opcion){
                case 1: if (libros.size() < 3){
                    System.out.println("Ingrese los siguientes datos:");
                    System.out.println("ID: ");
                    id = sc.nextInt();
                    for (Libro libro : libros){
                        if(libro.getId() == id){
                            System.out.println("Error: la id ya existe dentro del sistema, por favor intente de nuevo con otra id"); error = true;}
                    }
                    if (error){break;}
                    System.out.println("Titulo: ");
                    sc.nextLine();
                    titulo = sc.nextLine();
                    System.out.println("Precio: ");
                    precio = sc.nextDouble();
                    System.out.println("Stock: ");
                    int stock = sc.nextInt(); 
                    Libro libro = new Libro(id, titulo, precio, stock);
                    libros.add(libro);
                    System.out.println("Libro ingresado correctamente");
                    break;
                    }else{
                    System.out.println("Error: La lista de libros está llena, no se pueden agregar mas");
                }break;
                case 2: if(libros.size() == 0){System.out.println("No hay libros registrados aun");break;}
                    for (Libro libro:libros){
                    libro.mostrarInfo();
                    System.out.println("");
                } break;
                case 3: 
                    System.out.println("Id del libro: ");
                    id = sc.nextInt();
                
                for (Libro libro : libros) {
                    if (libro.getId() == id) {
                        libroEncontrado = true;
                        System.out.println("Cantidad: ");
                        cantidad = sc.nextInt();
                        if(cantidad <= 0){
                            System.out.println("Error: cantidad invalida, debe ser superior a 0");break;
                        }else if(cantidad > libro.getStock()){
                            System.out.println("No hay stock suficiente para realizar la compra"); break;
                        }
                        double total = libro.getPrecio() * cantidad;
                        System.out.println("Total de la compra: "+total);
                        System.out.println("Desea confirmar la compra? 1-si/2-no");
                        int confirm = sc.nextInt();
                        switch (confirm) {
                            case 1:System.out.println("Gracias por comprar");libro.setStock(libro.getStock()-cantidad);break;
                            case 2:System.out.println("Compra cancelada");continue;
                            default:System.out.println("Opcion invalida");
                        }
                    }
                } if (libroEncontrado == false){ System.out.println("Libro no encontrado");}
                break;
                case 4: salir = true;break;
                default: System.out.println("Opcion invalida");
            }
        }
        
    }
    
}
