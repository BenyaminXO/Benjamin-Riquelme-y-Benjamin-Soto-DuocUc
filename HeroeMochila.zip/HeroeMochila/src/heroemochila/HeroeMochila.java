/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package heroemochila;

/**
 *
 * @author AL-Alumno
 */
public class HeroeMochila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Heroe heroe1 = new Heroe("Roberto");
        
        heroe1.mostrarEstado();
        heroe1.agregarItem("pocion");
        heroe1.agregarItem("botiquin");
        heroe1.agregarItem("veneno");
        heroe1.agregarItem("hongo");
        heroe1.agregarItem("hongo");
        heroe1.agregarItem("curita");
        heroe1.mostrarEstado();
        heroe1.usarItem("pocion");
        heroe1.usarItem("hongo");
        heroe1.usarItem("hongo");
        heroe1.usarItem("hongo");
        heroe1.mostrarEstado();
        heroe1.usarItem("botiquin");
        heroe1.usarItem("botiquin");
        heroe1.mostrarEstado();
    }
    
}
