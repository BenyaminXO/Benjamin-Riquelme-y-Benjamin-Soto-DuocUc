/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heroemochila;
import java.util.ArrayList;
/**
 *
 * @author AL-Alumno
 */
public class Heroe {
    private String nombre;
    private int vida = 100;
    private ArrayList<String> mochila = new ArrayList<>();
    
    public Heroe(String nombre){ this.nombre = nombre; }
    
    public int getVida(){return vida;}
    public void recibirDanio(int d){ 
        vida = vida - d;
        if(vida <= 0){
            System.out.println(nombre+" ha murto");
            vida = 0;
        }else{
            System.out.println(nombre+" recibio "+d+" daño");
        }
    }
    public void curar(int c){
        if(vida == 100){System.out.println(nombre+" ya tiene la vida maxima"); return;
        }else if(vida <= 0){System.out.println(nombre+" ya ha muerto"); return;
        }else if(vida + c > 100){
            c = 100-vida;
        }
        vida += c;
        System.out.println(nombre+" se curó "+c+ " de vida");
        
    }
    public boolean agregarItem(String item){
        if (mochila.size() < 5){
            mochila.add(item);
            System.out.println(nombre+" agarro "+item+ " del suelo");
            return true;
        }else{
            System.out.println("La mochila ya está llena");
            return false;
        }
    }
    public void usarItem(String item){
        if (mochila.contains(item)){
         switch(item){
                case "pocion": curar(30); mochila.remove("pocion"); break;
                case "botiquin": curar(50); mochila.remove("botiquin"); break;
                case "hongo": recibirDanio(30); mochila.remove("hongo"); break;
                case "veneno": recibirDanio(50); mochila.remove("veneno"); break;
                case "curita": curar(10); mochila.remove("curita"); break;
            }
        }else{
            System.out.println("La mochila no tiene este item");
        }
    }
    public void mostrarEstado(){
        System.out.println("Nombre: "+nombre);
        System.out.println("Vida: "+vida);
        System.out.println("Mochila: "+mochila);
    }
}
