/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colegio;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author AL-Alumno
 */
public class Colegio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<String> curso = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        boolean salir = false;

        System.out.println("====MENU OPCIONES====");
        System.out.println("1.- Agregar");
        System.out.println("2.- Eliminar");
        System.out.println("3.- Buscar");
        System.out.println("4.- Salir");
        do {
            System.out.println("elija una opcion");
            int opcion = sc.nextInt();
            String estudiante = "null";
            if(opcion != 4){
                System.out.println("ingrese el nombre del estudiante");
                estudiante = sc.nextLine();
                estudiante = sc.nextLine();
            }
            switch (opcion) {
                case 1:
                    if (curso.contains(estudiante)) {
                        System.out.println("El estudiante ya está en el curso");
                        break;
                    }
                    ;
                    curso.add(estudiante);
                    System.out.println("El estudiante se añadio al curso");
                    break;
                case 2:
                    if (!curso.contains(estudiante)) {
                        System.out.println("El estudiante no está en el curso");
                        break;
                    }
                    ;
                    curso.remove(estudiante);
                    System.out.println("El estudiante se elimino del curso");
                    break;
                case 3:
                    if (!curso.contains(estudiante)) {
                        System.out.println("El estudiante no está en el curso");
                        break;
                    }
                    ;
                    int a = curso.indexOf(estudiante);
                    System.out.println("El estudiante se encuentra en la posicion: " + a);
                    break;
                case 4:
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion ingresada incorrecta");
            }
        } while (!salir);

    }

}
