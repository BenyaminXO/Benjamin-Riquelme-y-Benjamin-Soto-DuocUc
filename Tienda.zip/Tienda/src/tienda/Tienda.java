/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tienda;
import java.util.ArrayList;
/**
 *
 * @author AL-Alumno
 */
public class Tienda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<String> productos = new ArrayList<>();
        productos.add("Camiseta");
        productos.add("Poleron");
        productos.add("Mouse");
        productos.add("Extintor");
        productos.add("Auto");
        productos.set(1, "Casa");
        if(productos.contains("mouse")){
            productos.remove("mouse");
        }else{
            System.out.println("El producto mouse no está en la lista");
        }
        System.out.println(productos);
        
        System.out.println("Posicion del extintor: " + productos.indexOf("Extintor"));
        
        for (int i = 0; i < productos.size() ;i++){
            System.out.println(i+".- "+productos.get(i));
        }
    }
}
